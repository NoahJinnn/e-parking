from enum import Enum


class Request(Enum):
    REGISTER = 1
    CHECKIN = 2
    CHECKOUT = 3
