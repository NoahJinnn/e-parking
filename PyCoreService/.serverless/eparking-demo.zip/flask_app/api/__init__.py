from flask_app.api.v1.device.devices import devices_mod
from flask_app.api.v1.parking.parks import parks_mod
