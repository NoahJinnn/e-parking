from .device import DeviceModel as Device
from .park import ParkModel as Park
